H3.b
